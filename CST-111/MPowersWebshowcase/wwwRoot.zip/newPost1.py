def addpost():
    postTitle = input("Please enter the title for this post: ")
    postDesc = input("Please enter the description for this post: ")
    content = input("Please enter the content for this post: ")
    postFile = input("Please enter the filename for this post: ")

    text_list=['<div class="post-container">\n',
               '    <p style="text-align: center;">' + postDesc + '</p>\n',
               '    <h1 class="Label">' + postTitle + '</h1>\n',
               '        <form>\n',
               '            <div class="description">' + content + '</div>\n',
               '            <Filename: <a href="./reports' + postFile + '"> ' + postFile + '</a>\n'
               '        </form>\n',
               '</div>\n'
              ]  

    file = open("./ClassProject.html", "a")
    file.write(" ")
    file.writelines(text_list)
    file.close()

addpost()