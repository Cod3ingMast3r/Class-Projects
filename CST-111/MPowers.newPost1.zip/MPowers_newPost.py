def addpost():
    postTitle = input("Please enter the title for this post: ")
    postDesc = input("Please enter the description for this post: ")
    postFile = input("Please enter the filename for this post: ")

    file = open("D:\CST-111\ClassProject.html", "a")
    file.write(" ")
    file.write('<p>New Data from newPost1.py</p>')
    file.write('<p>Title:' + postTitle + '</p>')
    file.write('<p>Desciption:' + postTitle + '</p>')
    file.write('<Filename: <a href="./reports' + postFile + '"> ' + postFile + '</a>')
    file.close()

addpost()
