#include <iostream>
#include <ctime>
#include "Dice.h"
#include "Player.h"
using namespace std;
int oldValue = 0;
int main()
{
	srand(time(NULL));
	Player me;
	me.getTotal();		
}

